#ifndef __SYSTYPE_H
#define __SYSTYPE_H

#define OSTYPE_LINUX

#endif /* SYSTYPE_H */
