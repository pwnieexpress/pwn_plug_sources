/*
  base64.h

  Base-64 routines.

  $Id: base64.h,v 1.1 2000/05/16 17:31:14 dugsong Exp $
*/

#ifndef BASE64_H
#define BASE64_H

int	base64_pton(char const *, u_char *, size_t);

#endif /* BASE64_H */

