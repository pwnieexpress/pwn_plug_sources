#define MAXIPLEN 17
#define MAXNAMELEN 128
char user[10];
int irc;

