#include <stdio.h>
#define OUTPUT_LOCALITY "output.txt"
FILE *wfp;
fpos_t file_loc;
char filename[64];
extern char outputfile[64];
