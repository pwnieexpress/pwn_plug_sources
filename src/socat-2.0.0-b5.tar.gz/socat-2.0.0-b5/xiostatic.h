/* $Id$ */
/* Copyright Gerhard Rieger 2006 */
/* Published under the GNU General Public License V.2, see file COPYING */

/* libxio internal global variables */
#ifndef __xiostatic_h
#define __xiostatic_h 1

extern int xio_flags;

#endif /* !defined(__xiostatic_h) */
