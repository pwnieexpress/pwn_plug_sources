/* source: xio-gopen.h */
/* Copyright Gerhard Rieger 2001-2007 */
/* Published under the GNU General Public License V.2, see file COPYING */

#ifndef __xio_gopen_h_included
#define __xio_gopen_h_included 1

extern const struct xioaddr_endpoint_desc xioaddr_gopen1;
extern const union xioaddr_desc *xioaddrs_gopen[];

#endif /* !defined(__xio_gopen_h_included) */
