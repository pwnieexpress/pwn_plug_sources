/* source: xio-interface.h */
/* Copyright Gerhard Rieger 2008 */
/* Published under the GNU General Public License V.2, see file COPYING */

#ifndef __xio_interface_h_included
#define __xio_interface_h_included 1

extern const union xioaddr_desc *xioaddrs_interface[];

#endif /* !defined(__xio_interface_h_included) */
