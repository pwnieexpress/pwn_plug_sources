typedef union {
     int val;
     unsigned char str[8192];
} YYSTYPE;
#define	NAME_	257
#define	NUM_	258
#define	DOT_DOT_	259
#define	STRUCT_	260
#define	SELECT_	261
#define	OPAQUE_	262
#define	ENUM_	263
#define	DIGITALLY_SIGNED_	264
#define	COMMENT_START_	265
#define	CODE_	266
#define	COMMENT_END_	267
#define	CASE_	268
#define	CONSTANT_	269


extern YYSTYPE yylval;
