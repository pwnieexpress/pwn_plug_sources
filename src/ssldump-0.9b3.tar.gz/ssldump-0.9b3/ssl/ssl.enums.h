extern decoder ContentType_decoder[];
extern decoder HandshakeType_decoder[];
extern decoder cipher_suite_decoder[];
extern decoder AlertLevel_decoder[];
extern decoder AlertDescription_decoder[];
extern decoder compression_method_decoder[];
extern decoder client_certificate_type_decoder[];
