
/* $Id: ec_version.h,v 1.20 2005/05/31 07:59:54 alor Exp $ */

#ifndef EC_VERS_H
#define EC_VERS_H

#define EC_VERSION            "0.7.4.1"
#define EC_VERSION_MAJOR      0
#define EC_VERSION_MINOR      7
#define EC_VERSION_REVISION   4
#define EC_PROGRAM            "ettercap"
#define EC_COPYRIGHT          "2001-2011"
#define EC_AUTHORS            "ALoR & NaGA"

#endif

/* EOF */

