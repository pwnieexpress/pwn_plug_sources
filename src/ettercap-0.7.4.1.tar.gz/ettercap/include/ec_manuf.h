
/* $Id: ec_manuf.h,v 1.3 2004/07/24 10:43:21 alor Exp $ */

#ifndef EC_MANUF_H
#define EC_MANUF_H

EC_API_EXTERN int manuf_init(void);
EC_API_EXTERN char * manuf_search(char *m);

#endif

/* EOF */

// vim:ts=3:expandtab

