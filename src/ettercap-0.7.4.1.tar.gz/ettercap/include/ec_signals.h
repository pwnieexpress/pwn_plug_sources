
/* $Id: ec_signals.h,v 1.5 2004/07/24 10:43:21 alor Exp $ */

#ifndef EC_SIGNAL_H
#define EC_SIGNAL_H

EC_API_EXTERN void signal_handler(void);

#endif

/* EOF */

// vim:ts=3:expandtab

