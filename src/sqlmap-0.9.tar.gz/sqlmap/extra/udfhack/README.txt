Files in this folder can be used to compile shared objects that define
some user-defined functions for MySQL and PostgreSQL. They are licensed
under the terms of the GNU Lesser General Public License and their
compiled versions are available on the official sqlmap subversion
repository[1].

[1] https://svn.sqlmap.org/sqlmap/trunk/sqlmap/udf/
