PostgreSQL does not compile under Windows 64-bit.
