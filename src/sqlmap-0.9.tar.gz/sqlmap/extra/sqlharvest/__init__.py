#!/usr/bin/env python

"""
$Id: __init__.py 2195 2010-10-29 09:59:18Z stamparm $

Copyright (c) 2006-2010 sqlmap developers (http://sqlmap.sourceforge.net/)
See the file 'doc/COPYING' for copying permission
"""

pass
