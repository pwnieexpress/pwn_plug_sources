#!/usr/bin/env python

"""
$Id: __init__.py 2318 2010-11-09 09:42:43Z stamparm $

Copyright (c) 2006-2010 sqlmap developers (http://sqlmap.sourceforge.net/)
See the file 'doc/COPYING' for copying permission
"""

pass
