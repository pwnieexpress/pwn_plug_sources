#define _MAJ 1
#define _MIN 1
#define _SUB_MIN 0
#define _BETA 0
#define _RC 0
#define WEBSITE "http://www.aircrack-ng.org"
