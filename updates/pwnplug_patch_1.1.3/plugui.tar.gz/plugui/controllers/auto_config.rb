class PlugUI < Sinatra::Base
  get '/ssh-receiver/generate/?' do
    unless File.exists?('/root/.ssh/id_rsa.pub')
      Ssh.generate_keypair
    end

    AutoConfig.generate!
    redirect '/SSH_receiver_autoconfig.sh'
  end
end
