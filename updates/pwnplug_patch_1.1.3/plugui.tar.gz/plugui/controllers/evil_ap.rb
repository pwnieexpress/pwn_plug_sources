class PlugUI < Sinatra::Base
  def evil_ap_options
    @title = "Evil AP"
    @service_current = "current"
  end

  get '/evil-ap/?' do
    evil_ap_options
    erb :evil_ap
  end

  post '/evil-ap/?' do
    # Limit the length to reduce potential attack vectors
    ssid = params[:ssid].nil? ? nil : params[:ssid][0..127]
    evil_ap_options
    EvilAp.start!(ssid)
    redirect '/evil-ap'
  end

  post '/evil-ap/stop/?' do
    EvilAp.stop!
    redirect '/evil-ap'
  end
end
