class PlugUI < Sinatra::Base
  def ssh_settings
    @title="SSH Keys"
    @setup_current = "current"
  end

  get '/ssh_keygen/?' do
    ssh_settings
    erb :ssh_keygen
  end

  post '/ssh_keygen/?' do
    ssh_settings
    Ssh.reset!
    erb :ssh_keygen
  end
end
