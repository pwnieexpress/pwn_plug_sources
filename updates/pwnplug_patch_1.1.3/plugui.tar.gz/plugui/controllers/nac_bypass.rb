class PlugUI < Sinatra::Base
  def nac_bypass_settings
    @title = "NAC/802.1x Bypass"
    @service_current = "current"
  end

  get '/nac-bypass/?' do
    nac_bypass_settings
    erb :nac_bypass
  end

  post '/nac-bypass/?' do
    nac_bypass_settings
    NacBypass.enable!
    @alert = "Success: NAC Bypass mode will be enabled at next boot. Refer to manual for deployment instructions."
    erb :nac_bypass
  end
end
