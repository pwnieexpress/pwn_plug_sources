class PlugUI < Sinatra::Base
  def stealth_mode_settings
    @title = "Stealth Mode"
    @service_current = "current"
  end

  get '/stealth-mode/?' do
    stealth_mode_settings
    erb :stealth_mode
  end

  post '/stealth-mode/?' do
    stealth_mode_settings
    @alert = "Success: Stealth mode will be enabled at next boot. Refer to the manual for more details."
    StealthMode.enable!
    erb :stealth_mode
  end
end
