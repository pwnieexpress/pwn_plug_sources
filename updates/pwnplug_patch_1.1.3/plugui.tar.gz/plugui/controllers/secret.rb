class PlugUI < Sinatra::Base
  def secret_options
    @title= "Change Plug UI Passsword"
    @setup_current = "current"
  end

  get '/secret/?' do
    secret_options
    erb :secret
  end

  post '/secret/?' do
    secret_options

    if params[:new_secret] != params[:new_secret_confirmation]
      @alert = "Please enter the same password into both fields"
      erb :secret
    elsif params[:new_secret].include?("'") || params[:new_secret].include?('"') || params[:new_secret].include?("!")
      @alert = "Passphrase cannot include ', \" or !"
      erb :secret
    elsif shellescape(params[:new_secret]) != params[:new_secret]
      @alert = "Passphrase cannot include special shell characters"
      erb :secret
    else
      # We already tested to make sure the shell escape was the same but it
      # couldn't hurt to ensure it isn't funky.
      hashed_secret =  Secret.sha512sum(shellescape(params[:new_secret]))
      Secret.write_secret!(hashed_secret)
      redirect '/'
    end
  end

  def shellescape(str)
    # An empty argument will be skipped, so return empty quotes.
    return "''" if str.empty?

    str = str.dup

    # Process as a single byte sequence because not all shell
    # implementations are multibyte aware.
    str.gsub!(/([^A-Za-z0-9_\-.,:\/@\n])/n, "\\\\\\1")

    # A LF cannot be escaped with a backslash because a backslash + LF
    # combo is regarded as line continuation and simply ignored.
    str.gsub!(/\n/, "'\n'")

    return str
  end
end
