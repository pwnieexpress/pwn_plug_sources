class PlugUI < Sinatra::Base
  def networking_settings
    @title = "Network Config"
    @setup_current ="current"
  end

  get '/network-config/?' do
    networking_settings
    erb :network_config
  end

  post '/network-config/static_ip/?' do
     networking_settings
     required = [ :ip, :netmask, :gateway, :dns]

     errors = required.map { |r| params[r] == "" ? true : false }

     if errors.include?(true)
       @static_ip_error = "All Fields Required"
     else
       @alert = "New settings applied successfully."
       Network.static_ip!(params)
     end

     erb :network_config
  end

  post '/network-config/dhcp/?' do
    networking_settings
    @alert = "DHCP lease renewed."
    Network.enable_dhcp!
    erb :network_config
  end

  post '/network-config/hostname/?' do
    # Hostnames not allowed to be more than 64 characters per RFC, limit our attack surface
    hostname = params[:hostname].nil? ? nil : params[:hostname][0..63]
    networking_settings
    @alert = "Hostname has been updated to \"#{hostname}\"."
    Network.update_hostname(hostname)
    erb :network_config
  end
end
