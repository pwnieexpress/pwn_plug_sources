class PlugUI < Sinatra::Base
  def system_settings
    @title="System Status"
    @system_current ="current"
  end

  get '/system/?' do
    cache_control :max_age => 0
    system_settings
    erb :system
  end

  get '/help/?' do
    @title = "Plug UI Help"
    @help_current = "current"
    erb :help
  end

  post '/reboot/?' do
    System.reboot!
  end
end
