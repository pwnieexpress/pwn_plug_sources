class PlugUI < Sinatra::Base
  def service_options
    @title = "Plug Services"
    @service_current = "current"
  end

  get '/services/?' do
    cache_control :max_age => 0
    service_options
    erb :services
  end

  helpers do
    def active_service_button(status=nil)
      case status
      when true
        return "<img src='/active_button.png' alt='Enabled' title='Enabled' class='status_button' />"
      when false
        return "<img src='/inactive_button.png' alt='Disabled' title='Disabled'class='status_button' />"
      else
        return "<img src='/default_button.png' alt='Status N/A' title='Status N/A' class='status_button' />"
      end
    end
  end
end
