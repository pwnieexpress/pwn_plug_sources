# Pwnie Expreiss Plug UI Revision: 11.15.2011 Copyright 2010-2015 Rapid Focus
# Security, LLC, DBA Pwnie Express pwnieexpress.com
#
# This file contains proprietary software distributed under the terms of the
# Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security,
# LLC End User License Agreement (EULA).
#
## Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf

class PlugUI < Sinatra::Base
  # PwnPlug is the module that all other classes are loaded into.
  include PwnPlug

  # Require basic auth
  use Rack::Auth::Basic do |username, password|
    [username, Secret.sha512sum(password)] == ['plugui', PwnPlug::Secret.current_secret]
  end

  # set application root
  set :root, File.dirname(__FILE__)

  # override default sinatra not_found method to
  # take into account the LOCALHOST_ONLY option
  not_found do
    "<h1>Resource Not Found or Access restricted from #{request.ip}</h1>"
  end

  # before filter for localhost only
  before do
    if  LOCALHOST_ONLY == true
      !request.ip.eql?('127.0.0.1') ? not_found  : ''
    end
  end

  get '/?' do
    redirect '/setup'
  end
end
