# Pwnie Expreiss Plug UI Revision: 11.15.2011
# Copyright 2010-2015 Rapid Focus Security, LLC, DBA Pwnie Express
# pwnieexpress.com
#
# This file contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
## Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf

# Add the current directory to the path
$:.push File.dirname(File.expand_path("./", __FILE__))

require 'rubygems'
require 'sinatra'
require 'erb'

# switch this to true if you only want to be able
# to access the ui from 127.0.0.1
LOCALHOST_ONLY = false

#SSL settings for webrick
CERT_PATH         = '/etc/ssl/private/'
OPENSSL_X509_CERT = File.read( CERT_PATH + "plugui_cert.pem" )
OPENSSL_PKEY_RSA  = File.read( CERT_PATH + "plugui_key.pem" )

# Declare this first so it is available
module PwnPlug
end

require 'plugui.rb'

Dir["models/*.rb"].each {|file| require file }
Dir["scripts/*.rb"].each {|file| require file }
Dir["controllers/*.rb"].each {|file| require file }

## SSL requirements
require 'webrick'
require 'webrick/https'
require 'openssl'


# This helps with startup time because we are specifying :BindAdress in webrick_options
Socket.do_not_reverse_lookup = true


webrick_options = {
  :BindingAddress     => '0.0.0.0',
  :Port               => 8443,
  :Logger             => WEBrick::Log::new($stderr, WEBrick::Log::DEBUG),
  :DocumentRoot       => '/var/pwnplug/plugui/public',
  :SSLEnable          => true,
  :SSLVerifyClient    => OpenSSL::SSL::VERIFY_NONE,
  :SSLCertificate     => OpenSSL::X509::Certificate.new( OPENSSL_X509_CERT ),
  :SSLPrivateKey      => OpenSSL::PKey::RSA.new( OPENSSL_PKEY_RSA ),
  :SSLCertName        => [ [ "CN",WEBrick::Utils::getservername ] ]
}

Rack::Handler::WEBrick.run PlugUI, webrick_options
