#!/bin/bash
echo "[+] Generating a self-signed certificate."
echo "[+] Creating private key."
openssl genrsa -des3 -out privkey.pem 1024
echo "[+] Creating certificate signing request with private key."
openssl req -new -key privkey.pem -out cert.csr
echo "[+] Backing up password protected private key."
cp privkey.pem privkey.pem.orig
echo "[+] Removing password from private key."
openssl rsa -in privkey.pem.orig -out privkey.pem
echo "[+] Creating certificate"
openssl req -new -x509 -key privkey.pem -out cacert.pem -days 1095
echo "[+] Certificate generated."
echo "[=] Copy to /etc? [Press ctrl-c to quit]"
mkdir -p /etc/ssl/private
cp cacert.pem /etc/ssl/private/plugui_cert.pem
cp privkey.pem /etc/ssl/private/plugui_key.pem
