module PwnPlug
  class SmsConfig < PwnScript
    def config
       super.merge({
         :config_file => "sms_message_config.sh"
       })
     end

    def self.is_enabled?
      full_path = self.new.full_path

      self.clear! unless File.exists?(full_path)

      File.read(full_path) != ''
    end

    def self.clear!
      self.new.blank_out_script
    end

    def self.check_sms_tls(value)
      current = PwnScript.call_value('smtp_tls', 'sms_message_config.sh')
      (current == value) ? "selected=\"selected\"" : ""
    end

    def self.send_test_message(options={})
      options = options.each_with_object({}) { |(k,v),o| o[k] = shellescape(v) }

      `sendEmail -f "#{options[:sms_sender]}" -t "#{options[:sms_recipient]}" -u "#{options[:msg_subject]}" -m "#{options[:msg_body]}" -s "#{options[:smtp_server]}" -o tls="#{options[:smtp_tls]}" -xu "#{options[:smtp_auth_user]}" -xp "#{options[:smtp_auth_password]}"`
    end

    def self.sms_alert
      sleep 2
      System.run_script('/var/pwnplug/scripts/sms_message.sh')
    end

    def make_script(options=@script_values)
      options = options.each_with_object({}) { |(k,v),o| o[k] = shellescape(v) }

      script  = "sms_recipient=\"#{options[:sms_recipient]}\"\n"
      script << "sms_sender=\"#{options[:sms_sender]}\"\n"
      script << "smtp_server=\"#{options[:smtp_server]}\"\n"
      script << "smtp_auth_user=\"#{options[:smtp_auth_user]}\"\n"
      script << "smtp_auth_password=\"#{options[:smtp_auth_password]}\"\n"
      script << "smtp_tls=\"#{options[:smtp_tls]}\"\n"
      script << "msg_subject=\"#{options[:msg_subject]}\"\n"
      script << "msg_body=\"#{options[:msg_body]}\"\n"
      script
    end
  end
end
