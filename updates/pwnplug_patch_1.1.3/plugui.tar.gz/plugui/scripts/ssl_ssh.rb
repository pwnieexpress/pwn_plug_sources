module PwnPlug
  class SslSsh < PwnScript
    def config
      super.merge({
        :port => 3336,
        :config_file => "reverse_ssh_over_SSL_config.sh",
        :script_file => "reverse_ssh_over_SSL.sh"
      })
    end

    def make_script(options = @script_values)
      script = "stunnel_receiver=#{shellescape(options[:ip])}\n"
      script
    end
  end
end
