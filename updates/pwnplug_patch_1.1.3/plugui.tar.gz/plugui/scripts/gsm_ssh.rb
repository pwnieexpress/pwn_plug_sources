module PwnPlug
  class GsmSsh < PwnScript
    def config
      super.merge({
        :port => 3337,
        :config_file => "reverse_ssh_over_3G_config.sh",
        :script_file => "reverse_ssh_over_3G.sh"
      })
    end

    def self.param_to_adapter(param)
      case param
      when "Unlocked GSM"
        "e160"
      when "Verizon/Virgin Mobile"
        "1xevdo"
      when "T-Mobile Rocket 4G"
        "tmobile"
      else
        "e160"
      end
    end

    def self.selected_adapter(adapter)
      if GsmSsh.check_selected_adapater(adapter)
        'selected="selected"'
      end
    end

    def self.check_selected_adapater(adapter)
      `grep -o "#{ adapter }" /var/pwnplug/script_configs/reverse_ssh_over_3G_config.sh` != ""
    end

    def make_script(options = @script_values)
      script =  "PPP_peer=#{ GsmSsh.param_to_adapter( shellescape(options[:adapter]) ) }\n"
      script << "SSH_receiver=#{ shellescape(options[:ip]) }\n"
      script << "SSH_receiver_port=#{ shellescape(options[:port]) }\n"
      script
    end
  end
end
