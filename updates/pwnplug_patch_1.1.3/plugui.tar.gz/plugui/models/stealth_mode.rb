module PwnPlug
  class StealthMode
    ENABLE_SCRIPT = '/var/pwnplug/scripts/Enable_stealth_mode.sh'

    def self.enable!
      System.run_script(ENABLE_SCRIPT)
    end
  end
end
