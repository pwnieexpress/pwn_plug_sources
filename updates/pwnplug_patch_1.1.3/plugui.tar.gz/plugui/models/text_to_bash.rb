module PwnPlug
  class TextToBash

    INCOMING_MESSAGES          = '/var/spool/sms/incoming/messages'
    OUTGOING_FOLDER            = '/var/spool/sms/outgoing/'
    AUTHORIZED_NUMBER_LOCATION = File.join(Dir.pwd, '.authorized_number')
    CHUNK_SIZE                 = 146
    MAX_NUMBER_OF_CHUNKS       = 5

    def self.is_enabled?
      result = `ps ax | grep -v grep | grep -o smsd |tail -n1`.chomp

      (result == 'smsd')
    end

    def self.has_adapter?
      File.exists?('/dev/ttyUSB0')
    end

    def self.disable!
      TextToBash.kill_smsd
    end

    def self.enable!(number)
      TextToBash.write_authorized_number!(number)
      TextToBash.start_smsd
    end

    def self.start_smsd
      `cd /var/pwnplug/scripts && ./Enable_text-to-bash.sh &`
       sleep 8
    end

    def self.kill_smsd
       System.run_script('/var/pwnplug/scripts/Disable_text-to-bash.sh')
    end

    def self.authorized_number
      File.read(AUTHORIZED_NUMBER_LOCATION).chomp
    end

    def self.write_authorized_number!(number)
      f = File.open(AUTHORIZED_NUMBER_LOCATION,'w')
      f.write(number)
      f.close
    end

    def self.tail
      System.tail('/var/log/smsd.log')
    end

    # instance methods for runs on new messages
    def check_for_messages
      incoming_message = File.read(INCOMING_MESSAGES)

      if incoming_message.length > 0
        reset_incoming_messages
        initiate_run(incoming_message)
      end
    end

    def initiate_run(message)
      @parsed_message = parse_message(message)

      if (@parsed_message[:phone] == authorized_phone) && (authorized_phone != '')
        response_body = run_command!
        response_body = clean_resonse_body(response_body)
        send_chunks(response_body)
      else
        puts "Message received from unauthorized source number."
      end
    end

    def send_chunks(body)
      @outgoing_message = body
      hurl_chunks
    end

    def run_command!
      `#{ @parsed_message[:command] }`
    end

    def clean_resonse_body(response_body)
      response_body.gsub("\t",' ')
    end

    def authorized_phone
      TextToBash.authorized_number
    end

    def parse_message(message)
      output = {}
      output[:phone] = extract_phone_number(message)
      output[:command] =  extract_command(message)
      output
    end

    def extract_command(message)
      command_line = message.scan(/^.*::.*$/).first
      command_line.gsub!(':: ','') unless command_line.nil?
      command_line
    end

    def extract_phone_number(message)
      message.scan(/^.*#{TextToBash.authorized_number}.*$/).flatten.first
    end

    def reset_incoming_messages
      File.truncate(INCOMING_MESSAGES, 0)
    end

    def hurl_chunks
      chunk_array.each_with_index do |chunk,index|
        path = File.join(OUTGOING_FOLDER, 'chunk', index.to_s)
        string = "#{ TextToBash.authorized_number }\n#{chunk}"

        File.open(path, 'w') do |f|
          f.write(string)
        end
      end
    end

    def chunk_array
      outgoing_message = String.new(@outgoing_message)
      outgoing_message = outgoing_message.slice(0,max_message_length)
      output = []

      until outgoing_message.length <= CHUNK_SIZE
        output << outgoing_message.slice!(0...CHUNK_SIZE)
      end

      output << outgoing_message
      output
    end

    def max_message_length
      CHUNK_SIZE * MAX_NUMBER_OF_CHUNKS
    end
  end
end
