module PwnPlug
  class EvilAp
    START_SCRIPT = '/var/pwnplug/scripts/evilap.sh'
    STOP_SCRIPT  = '/var/pwnplug/scripts/evilap_stop.sh'

    def self.start!(ssid)
      EvilConfig.new({:ssid => ssid}).write_script
      System.run_script(START_SCRIPT)
    end

    def self.stop!
      System.run_script(STOP_SCRIPT)
    end

    def self.is_running?
      `ps ax | grep -v grep | grep -o "airbase-ng"` != ""
    end

    def self.tail
      System.tail('/var/log/evilap.log')
    end

    def self.has_adapter?
      `ifconfig -a | grep -o wlan0`.chomp == 'wlan0'
    end
  end
end
