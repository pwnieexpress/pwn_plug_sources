module PwnPlug
  class AutoConfig
    GENERATOR_SCRIPT   = '/var/pwnplug/scripts/Generate_SSH_receiver_autoconfig.sh'
    AUTO_CONFIG_SCRIPT = '/var/pwnplug/scripts/SSH_receiver_autoconfig.sh'

    def self.generate!
      System.run_script(GENERATOR_SCRIPT)

      # copy into public directory for download
      File.open(File.join(Dir.pwd, '/public/SSH_receiver_autoconfig.sh'), 'w') do |f|
        f.write(AutoConfig.body)
      end
    end

    def self.body
      unless File.exists?(AUTO_CONFIG_SCRIPT)
        File.open(AUTO_CONFIG_SCRIPT, 'w') do |f|
          f.write('')
        end
      end

      File.read(AUTO_CONFIG_SCRIPT)
    end
  end
end
