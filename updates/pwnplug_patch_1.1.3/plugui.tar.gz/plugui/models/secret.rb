module PwnPlug
  class Secret
    LOCATION = File.join(Dir.pwd, '.secret')

    def self.current_secret
      File.read(LOCATION).chomp
    end

    def self.write_secret!(new_secret)
      File.open(LOCATION, 'w') do |f|
        f.write(new_secret)
      end
    end

    def self.sha512sum(string)
      `echo "#{ string }" | sha512sum`.chomp
    end
  end
end
