module PwnPlug
  class Network
    def self.current_settings
      output = {}
      eth0 = IfconfigParser.ifconfig('eth0')
      output[:mode] = Network.mode
      output[:ip_address] = eth0['addr']
      output[:netmask] = eth0['Mask']
      output[:default_gateway] = Network.default_gateway
      output[:primary_dns_server] = Network.primary_dns_server
      output[:mac_address] = eth0['HWaddr']
      output[:hostname] = Network.hostname
      output
    end

    class IfconfigParser
      MAC_REGEX = /^(\S{1,2}:\S{1,2}:\S{1,2}:\S{1,2}:\S{1,2}:\S{1,2})?$/

      # NOTE: this has some slightly weird results for wlan interfaces. Really
      # meant to be used for eth0
      def self.ifconfig(iface)
        output = Hash.new

        ifconfig_string          = `ifconfig #{ iface }`
        ifconfig_string.gsub!("RX ", "RX_")
        ifconfig_string.gsub!("TX ", "TX_")
        ifconfig_string.gsub!(" (", "_(")

        raw_array                = ifconfig_string.split(' ').keep_if { |k| k =~ /:/ }
        output["HWaddr"]         = raw_array.each { |seg| break seg if seg =~ MAC_REGEX }
        output["ipv6_addr"]      = ifconfig_string.split("\n").each { |line| break line if line =~ /^.*inet6.*$/ }
        output["ipv6_addr"]      = output["ipv6_addr"].split[2] unless output["ipv6_addr"] == nil

        hash_array = raw_array.map {|e| e.split(':') }
        hash_array.reject!{|e| e.length != 2 }
        hash_array.inject(output) do |output, element|
          output[element[0]] = element[1]
          output
        end

        output
      end
    end

    def self.append_to_etc_network_interface(string)
      string = string + "\n\n"
      System.append_to_file("/etc/network/interfaces",string)
    end

    def self.static_ip!(params)
      `echo "nameserver #{params[:dns]}" > /etc/resolv.conf && route del default & route del default & sleep 2`

      string = "auto eth0\niface eth0 inet static\naddress #{params[:ip]}\nnetmask #{params[:netmask]}\ngateway #{params[:gateway]}\n"

      Network.append_to_etc_network_interface(string)
      Network.networking_restart
    end

    def self.enable_dhcp!
      string = "allow-hotplug eth0\niface eth0 inet dhcp"
      Network.append_to_etc_network_interface(string)
      Network.networking_restart
    end

    def self.randomize_mac
      `macchanger -r eth0`
    end

    def self.update_hostname(hostname)
      `echo #{hostname} > /etc/hostname &&/etc/init.d/hostname.sh start`
    end

    def self.networking_restart
      # `/etc/init.d/networking restart`
      `ifdown eth0 && ifup eth0`
    end

    def self.hostname
      `hostname`
    end

    def self.interfaces
      `ifconfig eth0`
    end

    def self.routes
      `route -n`
    end

    def self.resolv_dot_conf
      `cat /etc/resolv.conf`
    end

    def self.etc_network_interfaces
      `cat /etc/network/interfaces`
    end

    def self.static?
      !Network.etc_network_interfaces.split("\n").keep_if { |line| line =~ /^.*static.*$/ }.empty?
    end

    def self.mode
      Network.static? ? "Static" : "DHCP"
    end

    def self.default_gateway
      array = `ip route show`.split("\n").keep_if { |line| line =~ /default.*$/ }
      if array.size > 0
        array[0].split[2]
      else
        ''
      end
    end

    def self.primary_dns_server
      array = Network.resolv_dot_conf.split("\n").keep_if { |line| line =~ /nameserver.*$/ }
      if array.size > 0
        array[0].split(' ')[1]
      else
        ''
      end
    end
  end
end
