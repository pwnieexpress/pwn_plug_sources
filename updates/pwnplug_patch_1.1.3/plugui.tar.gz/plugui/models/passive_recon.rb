module PwnPlug
  class PassiveRecon
    ENABLE_SCRIPT  = '/var/pwnplug/scripts/Enable_passive_recon.sh'
    DISABLE_SCRIPT = '/var/pwnplug/scripts/Disable_passive_recon.sh'

    def self.enable!
      System.run_script(ENABLE_SCRIPT)
    end

    def self.enabled?
      `ps ax | grep -v grep | grep -o "tcpflow"` != ""
    end

    def self.disable!
      System.run_script(DISABLE_SCRIPT)
    end
  end
end
