Pwnie Express Platform UI
=========================

This is the README for the user interface of the Pwnie Express platform.

Features:
=========

* All devices include aggressive reverse tunneling capabilities for persistent remote SSH access.
* SSH over HTTP, DNS, ICMP, and other covert tunneling options are available for traversing strict firewall rules, web filters, & application-aware IPS.
* All tunnels are encrypted via SSH and will maintain access wherever the plug has an Internet connection - including wired, wireless, and 3G/GSM where available.

Getting Started:
================

* Configure the reverse shells in the UI, and enable DHCP or a static address for your target network.
* Start and configure your Backtrack SSH receiver with the provided script.
* Test the reverse shells to confirm all are working as expected
* Deploy the plug to the target network and watch your SSH receiver for incoming shells.

Usage:
======

* To manually stop the UI:  killall -9 ruby
* To manually start the UI:  /etc/init.d/plugui & 
** Note: If you manually start the UI from an SSH session, the UI will go offline as soon as that session is closed or disconnected.
** Note: A UI restart may be required after changing the device’s IP address.
* To disable UI autostart at bootup: update-rc.d -f  plugui remove.
* To enable UI autostart (runlevel 2 only):  update-rc.d -f plugui start 99 2 .
* UI output log: /var/pwnplug/plugui/webrick.log

For additional help please refer to the manual on the Pwnie Express Website. (http://www.pwnieexpress.com/support.html)
