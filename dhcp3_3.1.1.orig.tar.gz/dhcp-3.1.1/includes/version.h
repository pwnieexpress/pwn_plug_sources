/* Current version of ISC DHCP Distribution. */

#define DHCP_VERSION	"V3.1.1"
